package fr.reventemaline.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class VintedNotificationListener extends NotificationListenerService {
    private static final String CHANNEL = "vinted_alerts";

    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getPackageName() == null) return;
        String pkg = sbn.getPackageName().toLowerCase();
        // Vinted package names may vary by app version/market. Only relay Vinted notifications.
        if (!(pkg.equals("fr.vinted") || pkg.contains("vinted"))) return;

        // Privacy: do not copy, store, or display the notification's message/title contents.
        // This relays the event only; it cannot tell whether the notification is a new listing.
        long now = System.currentTimeMillis();
        String key = "last_" + Integer.toHexString((sbn.getKey() == null ? "vinted" : sbn.getKey()).hashCode());
        android.content.SharedPreferences prefs = getSharedPreferences("vinted_relay", MODE_PRIVATE);
        long last = prefs.getLong(key, 0L);
        if (now - last < 120000L) return;
        prefs.edit().putLong(key, now).apply();

        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Alertes Vinted", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Notifications relayées depuis Vinted");
            nm.createNotificationChannel(channel);
        }
        Intent open = getPackageManager().getLaunchIntentForPackage("fr.vinted");
        if (open == null) open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 77, open,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification n = builder
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Notification Vinted reçue")
                .setContentText("Ouvre Vinted pour vérifier s’il s’agit d’une bonne affaire.")
                .setContentIntent(pending)
                .setAutoCancel(true)
                .build();
        nm.notify((int)(now & 0x7fffffff), n);
    }
}
